import React from "react";

const CommunityManagement = () => {
  return <div>CommunityManagement</div>;
};

export default CommunityManagement;
